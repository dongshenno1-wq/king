// 云端配置 (Supabase Project Settings -> API)
window.PD_CFG = {
  SUPABASE_URL: 'https://ozsxasysitbeyyhvwvye.supabase.co',
  SUPABASE_ANON_KEY: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im96c3hhc3lzaXRiZXl5aHZ3dnllIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTM0MjM4MjMsImV4cCI6MjEwODk5OTgyM30.GKHKEJkBrO0scSUxFb07bDxO1TJKbmjIUDCCSisRRaE'
};
